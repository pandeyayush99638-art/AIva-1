package com.example.aiva

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * On-device model. Ek saath sirf EK generation chalta hai (busy flag) -- do saath chalne par crash hota tha.
 * Jawab stream hota hai (token-by-token), aur lamba bakwaas kaatne ke liye early-stop hai.
 */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    private val prefs = ctx.getSharedPreferences("aiva", Context.MODE_PRIVATE)
    val busy = AtomicBoolean(false)

    @Volatile private var onChunk: ((String) -> Unit)? = null
    @Volatile private var latch: CountDownLatch? = null

    val modelFile: File get() = File(ctx.filesDir, "model.task")
    fun hasModel(): Boolean = modelFile.exists() && modelFile.length() > 1_000_000

    private val safe: Boolean get() = prefs.getBoolean("safe", false)
    private val maxTokens: Int get() = if (safe) 768 else 1280
    val chatBudget: Int get() = if (safe) 1000 else 1800

    @Synchronized
    fun load() {
        if (llm != null) return
        prefs.edit().putString("inflight", "load").commit()
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile.absolutePath)
            .setMaxTokens(maxTokens)
            .setResultListener { partial, done ->
                onChunk?.invoke(partial ?: "")
                if (done) latch?.countDown()
            }
            .build()
        llm = LlmInference.createFromOptions(ctx, opts)
        prefs.edit().remove("inflight").commit()
    }

    fun reset() {
        try { (llm as? AutoCloseable)?.close() } catch (_: Throwable) {}
        llm = null
    }

    /** Chal rahe generation ko rokne ki koshish (agar library support kare). */
    fun stopNow(): Boolean {
        return try {
            val m = LlmInference::class.java.getMethod("cancelGenerateResponseAsync")
            m.invoke(llm)
            latch?.countDown()
            true
        } catch (e: Throwable) { false }
    }

    /** Blocking call (background thread se chalayein). Khaali string = engine busy. */
    fun ask(prompt: String, maxChars: Int = 600, stopAt: Char? = null, onPartial: (String) -> Unit = {}): String {
        if (!busy.compareAndSet(false, true)) return ""
        try {
            load()
            val sb = StringBuilder()
            val l = CountDownLatch(1)
            var ignoring = false
            latch = l
            onChunk = { c ->
                if (!ignoring) {
                    sb.append(c)
                    onPartial(sb.toString())
                    val hit = stopAt != null && sb.indexOf(stopAt.toString()) >= 0
                    if (hit || sb.length > maxChars) { ignoring = true; stopNow() }
                }
            }
            prefs.edit().putString("inflight", "gen").commit()
            llm!!.generateResponseAsync(prompt)
            l.await(150, TimeUnit.SECONDS)
            return sb.toString()
        } finally {
            onChunk = null
            latch = null
            prefs.edit().remove("inflight").commit()
            busy.set(false)
        }
    }
}
