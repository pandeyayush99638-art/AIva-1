# Aiva v2 - offline Android voice + phone agent
- Chat + voice conversation (continuous), spoken replies (TTS)
- Turant commands: "Settings kholo", "back", "home" (bina AI ke)
- Kaam (phone control) Accessibility Service se; risky buttons par ruk jaata hai
- Crash/safe-mode diagnostics
Model: litert-community/Gemma3-1B-IT (.task, q4)
