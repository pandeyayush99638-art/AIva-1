# Aiva - offline Android phone agent
Accessibility Service + MediaPipe on-device LLM. Sab kuch phone par chalta hai.
Build: Android Studio me kholo, ya GitHub Actions (build.yml) se APK banwao.
Model: Hugging Face "litert-community" se koi chhota Gemma/Qwen .task file download karein.
Safety: pay/buy/send/delete/confirm wale buttons par Aiva ruk jaata hai.
