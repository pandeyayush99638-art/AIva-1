package com.example.aiva

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Phone control. Simple kaam (app kholna, back, home) bina AI ke TURANT hote hain. */
class Agent(private val llm: LlmEngine, private val log: (String) -> Unit) {
    @Volatile var stop = false

    private val openRe1 = Regex("^(?:please\\s+|plz\\s+)?(?:open|launch|start)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val openRe2 = Regex(
        "^(.+?)\\s+(?:kholo|khol do|kholiye|khol de|chalao|chalu karo|open karo|खोलो|खोल दो|खोलिए|चलाओ|चालू करो)$",
        RegexOption.IGNORE_CASE)
    private val backRe = Regex("^(?:back|go back|wapas jao|wapas|peeche jao|peeche|पीछे जाओ|वापस जाओ|वापस)$", RegexOption.IGNORE_CASE)
    private val homeRe = Regex("^(?:home|go home|home jao|ghar jao|होम|होम जाओ)$", RegexOption.IGNORE_CASE)
    private val alias = mapOf(
        "सेटिंग" to "settings", "सेटिंग्स" to "settings", "क्रोम" to "chrome", "कैमरा" to "camera",
        "गैलरी" to "gallery", "व्हाट्सएप" to "whatsapp", "यूट्यूब" to "youtube", "फोन" to "phone",
        "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "मैप्स" to "maps", "जीमेल" to "gmail")

    /** Turant wale commands. Jawab text ya null (null = AI se poochho). */
    fun quick(text: String): String? {
        val svc = AgentService.instance ?: return null
        val t = text.trim().trimEnd('.', '!', '?', '।')
        if (backRe.matches(t)) { svc.back(); return "Peeche aa gaya." }
        if (homeRe.matches(t)) { svc.home(); return "Home screen par hoon." }
        var name = (openRe1.find(t)?.groupValues?.get(1) ?: openRe2.find(t)?.groupValues?.get(1)) ?: return null
        name = name.replace(Regex("\\s+app$", RegexOption.IGNORE_CASE), "").trim()
        if (name.length > 25 || name.split(" ").size > 3) return null
        name = alias[name] ?: name
        val r = svc.openApp(name)
        return if (r.startsWith("Opened")) "Ho gaya, $name khol diya." else r + "."
    }

    private fun taskPrompt(goal: String, history: List<String>, screen: String): String {
        val body = """
You control an Android phone to achieve this goal: $goal
Done so far: ${history.takeLast(4).joinToString("; ").ifBlank { "nothing" }}
Screen (id, label, abilities):
$screen

Choose the single next step. Reply with one JSON object, one of:
{"action":"open_app","name":"Settings"}
{"action":"tap","id":3}
{"action":"type","id":2,"text":"hi"}
{"action":"scroll"}
{"action":"back"}
{"action":"home"}
{"action":"done","summary":"short text"}
If the goal is complete, use done.
""".trimIndent()
        return "<start_of_turn>user\n" + body + "<end_of_turn>\n<start_of_turn>model\n{\"action\":\""
    }

    suspend fun run(goal: String, maxSteps: Int = 8): String {
        val svc = AgentService.instance ?: return "Pehle Accessibility me Aiva ko ON karein."
        stop = false
        val history = mutableListOf<String>()
        var lastSig = ""
        try {
            svc.home()
            delay(900)
            for (step in 1..maxSteps) {
                if (stop) return "Roka gaya."
                val screen = svc.readScreen().take(1200)
                val reply = withContext(Dispatchers.Default) {
                    try { llm.ask(taskPrompt(goal, history, screen), 200, '}') }
                    catch (e: Throwable) { "ERROR " + (e.message ?: e.javaClass.simpleName) }
                }
                if (stop) return "Roka gaya."
                if (reply.isBlank()) return "Aiva abhi pichhla kaam khatam kar raha hai, thodi der baad try karein."
                if (reply.startsWith("ERROR")) return "Model me dikkat aayi: " + reply.take(120)

                val raw = "{\"action\":\"" + reply
                val end = raw.indexOf('}')
                val json = try {
                    JSONObject(if (end >= 0) raw.substring(0, end + 1) else "$raw}")
                } catch (e: Exception) {
                    history.add("bad reply"); log("Step $step: jawab samajh nahi aaya"); continue
                }

                val action = json.optString("action")
                val sig = action + json.optInt("id", -1) + json.optString("text") + json.optString("name") + screen.hashCode()
                if (sig == lastSig) return "Ek hi step baar baar ho raha tha, isliye ruk gaya."
                lastSig = sig
                if (action == "done") return "Ho gaya. " + json.optString("summary")

                val result = when (action) {
                    "open_app" -> svc.openApp(json.optString("name"))
                    "tap" -> svc.tap(json.optInt("id", -1))
                    "type" -> svc.type(json.optInt("id", -1), json.optString("text"))
                    "scroll" -> svc.scroll()
                    "back" -> svc.back()
                    "home" -> svc.home()
                    else -> "Unknown action"
                }
                log("Step $step: $action → $result")
                if (result.startsWith("BLOCKED")) return "Suraksha ke liye ruk gaya. " + result.removePrefix("BLOCKED: ")
                history.add("$action: $result")
                delay(1300)
            }
            return "Step limit poori hui, shayad kaam adhura reh gaya."
        } finally {
            svc.openApp("Aiva")
        }
    }
}
