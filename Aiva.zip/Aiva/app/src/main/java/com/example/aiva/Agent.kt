package com.example.aiva

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Aiva ka dimaag-loop: screen dekho -> model se poocho -> action karo -> dohrao. */
class Agent(private val llm: LlmEngine, private val log: (String) -> Unit) {
    @Volatile var stop = false

    suspend fun run(goal: String, maxSteps: Int = 15) {
        val svc = AgentService.instance
        if (svc == null) { log("Pehle Accessibility settings me Aiva ko ON karo."); return }
        stop = false
        val history = mutableListOf<String>()
        try {
            svc.home()           // Aiva ki apni screen na padhe
            delay(1000)
            for (step in 1..maxSteps) {
                if (stop) { log("Roka gaya."); return }
                val screen = svc.readScreen()
                val prompt = """
You control an Android phone. Goal: $goal
Past actions: ${history.takeLast(6).joinToString(" | ").ifBlank { "none" }}
Current screen (id, label, abilities):
$screen

Reply with ONE JSON object only. Options:
{"action":"open_app","name":"Settings"}
{"action":"tap","id":3}
{"action":"type","id":2,"text":"hello"}
{"action":"scroll"}
{"action":"back"}
{"action":"home"}
{"action":"done","summary":"what you did"}
Use done as soon as the goal is complete.
""".trimIndent()

                val reply = withContext(Dispatchers.Default) {
                    try { llm.generate(prompt) } catch (e: Exception) { "ERROR ${e.message}" }
                }
                val json = try {
                    JSONObject(Regex("\\{[^{}]*\\}").find(reply)!!.value)
                } catch (e: Exception) {
                    history.add("bad reply"); log("Step $step: model ka jawab samajh nahi aaya"); continue
                }

                val action = json.optString("action")
                if (action == "done") { log("Ho gaya: " + json.optString("summary")); return }
                val result = when (action) {
                    "open_app" -> svc.openApp(json.optString("name"))
                    "tap" -> svc.tap(json.optInt("id", -1))
                    "type" -> svc.type(json.optInt("id", -1), json.optString("text"))
                    "scroll" -> svc.scroll()
                    "back" -> svc.back()
                    "home" -> svc.home()
                    else -> "Unknown action"
                }
                log("Step $step: $action -> $result")
                if (result.startsWith("BLOCKED")) { log("Aapki ijazat ke liye ruk gaya."); return }
                history.add(result)
                delay(1500)
            }
            log("Step limit poori ho gayi.")
        } finally {
            svc.openApp("Aiva")   // kaam ke baad wapas Aiva par aao
        }
    }
}
