package com.example.aiva

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.*
import java.io.File

class MainActivity : Activity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var llm: LlmEngine
    private lateinit var agent: Agent
    private lateinit var voice: Voice
    private lateinit var prefs: android.content.SharedPreferences

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var actionBtn: TextView
    private lateinit var stopBar: TextView
    private lateinit var setupCard: LinearLayout
    private lateinit var accRow: TextView
    private lateinit var modelRow: TextView
    private lateinit var orbBox: FrameLayout
    private lateinit var orbCore: View
    private lateinit var orbHalo: View
    private lateinit var orbLabel: TextView
    private lateinit var speakBtn: TextView
    private lateinit var langBtn: TextView
    private val modeChips = mutableListOf<TextView>()

    private val turns = mutableListOf<Pair<Boolean, String>>()
    private var mode = 0            // 0 Auto, 1 Baat, 2 Kaam
    private var speakOn = true
    private var voiceMode = false
    private var busy = false
    @Volatile private var cancelled = false
    private var job: Job? = null
    private var pulse: ValueAnimator? = null

    private val taskRe = Regex(
        "\\b(open|launch|call|dial|turn on|turn off|enable|disable|volume|brightness|wifi|wi-fi|bluetooth|flashlight|torch|scroll|click|tap|search|install|uninstall|screenshot|alarm|timer|whatsapp)\\b" +
        "|kholo|khol|chalu|chalao|band karo|on karo|off karo|bhejo|call karo|dhundo|khojo|खोलो|चालू|बंद|भेजो|कॉल|खोजो|ढूंढो",
        RegexOption.IGNORE_CASE)
    private val stopWords = Regex("^(stop|ruko|ruk jao|bas|chup|रुको|बंद करो|बस|चुप)$", RegexOption.IGNORE_CASE)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: String, r: Int, oval: Boolean = false) = GradientDrawable().apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
        setColor(Color.parseColor(color))
    }
    private fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; setTextColor(Color.WHITE)
        setPadding(dp(12), dp(7), dp(12), dp(7)); background = bg("#26265A", 16)
        setOnClickListener { onClick() }
    }
    private fun iconBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("aiva", MODE_PRIVATE)
        llm = LlmEngine(this)
        agent = Agent(llm) { msg -> runOnUiThread { note("• $msg") } }
        voice = Voice(this)
        voice.onHeard = { t -> onHeard(t) }
        voice.onListening = { on -> if (on) setOrb(1, "Sun raha hoon…") }
        voice.onNote = { m -> note(m); voiceMode = false; updateAction(); setOrb(0, "Taiyaar hoon") }
        voice.onSpeakEnd = { if (!voiceMode) setOrb(0, "Taiyaar hoon") }
        voice.init()

        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0B0B1E"), Color.parseColor("#1B1445"))))
        window.statusBarColor = Color.parseColor("#0B0B1E")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(30), dp(14), dp(10))
        }

        // ---- Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "Aiva"; textSize = 26f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        speakBtn = iconBtn("🔊") { toggleSpeak() }
        langBtn = iconBtn("हिं") { toggleLang() }
        val gear = iconBtn("⚙") {
            setupCard.visibility = if (setupCard.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        val trash = iconBtn("🗑") { chat.removeAllViews(); turns.clear() }
        listOf(speakBtn, langBtn, gear, trash).forEach { header.addView(it, LinearLayout.LayoutParams(dp(42), dp(38))) }
        root.addView(header)

        // ---- Orb
        orbHalo = View(this).apply { background = bg("#8B6CFF", 0, true); alpha = 0.28f }
        orbCore = View(this).apply { background = bg("#8B6CFF", 0, true) }
        orbBox = FrameLayout(this).apply {
            addView(orbHalo, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
            addView(orbCore, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
        }
        orbLabel = TextView(this).apply {
            text = "Taiyaar hoon"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#B9B6E8"))
        }
        root.addView(orbBox, LinearLayout.LayoutParams(dp(96), dp(96)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(4)
        })
        root.addView(orbLabel, LinearLayout.LayoutParams(-1, -2))

        // ---- Mode chips
        val modes = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("✨ Auto", "💬 Baat", "🤖 Kaam").forEachIndexed { i, s ->
            val c = chip(s) { mode = i; refreshModes() }
            modeChips.add(c)
            modes.addView(c, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        root.addView(modes, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // ---- Setup card
        setupCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg("#1E1E42", 14)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        accRow = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        modelRow = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1)
            }
        }
        setupCard.addView(accRow); setupCard.addView(modelRow)
        root.addView(setupCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        // ---- Chat
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })

        // ---- Stop bar (sirf kaam ke dauran)
        stopBar = TextView(this).apply {
            text = "⏹  Roko"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(18), dp(8), dp(18), dp(8)); background = bg("#E5484D", 18)
            visibility = View.GONE
            setOnClickListener { stopAll() }
        }
        root.addView(stopBar, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(6)
        })

        // ---- Quick chips
        val quick = LinearLayout(this)
        listOf("Settings kholo", "Chrome kholo", "Ek joke sunao", "Tum kya kar sakte ho?").forEach { s ->
            quick.addView(chip(s) { send(s) }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; addView(quick)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        // ---- Input bar
        input = EditText(this).apply {
            hint = "Aiva se kuch bhi kahein…"; textSize = 15f
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#8E8CB0"))
            background = bg("#1E1E42", 24); setPadding(dp(18), dp(10), dp(18), dp(10)); maxLines = 4
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { updateAction() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        actionBtn = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = bg("#7C5CFF", 24)
            setOnClickListener {
                val t = input.text.toString()
                if (t.isNotBlank()) { input.setText(""); send(t) } else toggleVoice()
            }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(actionBtn, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        setContentView(root)
        refreshModes(); updateAction(); setOrb(0, "Taiyaar hoon")
        aivaBubble("Namaste! Main Aiva hoon. Mujhse baat karein, ya 🎤 dabakar bolte rahein. “Settings kholo” jaise kaam bhi bata sakte hain.")

        reportLastCrash()
        warmUp()
    }

    // ---------------- Crash / safe mode ----------------
    private fun reportLastCrash() {
        val f = File(filesDir, "crash.txt")
        if (f.exists()) {
            note("⚠️ Pichhli baar app crash hua. Wajah:\n" + f.readText().take(350))
            f.delete()
        }
        val inflight = prefs.getString("inflight", null)
        if (inflight != null) {
            prefs.edit().putBoolean("safe", true).remove("inflight").commit()
            note(if (inflight == "load")
                "⚠️ Model load karte waqt app band hua. Safe mode ON kiya. Model file galat ya phone ke liye bhaari ho sakti hai (Gemma 3 1B q4 .task try karein)."
            else
                "⚠️ Jawab banate waqt app band hua (shayad memory kam padi). Safe mode ON kiya: chhote jawab, kam memory. Dusre apps band karke try karein.")
        }
    }

    // ---------------- Orb / UI state ----------------
    private fun setOrb(state: Int, label: String) {
        val c = Color.parseColor(when (state) { 1 -> "#2ECC71"; 2 -> "#FFB020"; 3 -> "#3DA5FF"; else -> "#8B6CFF" })
        (orbCore.background as GradientDrawable).setColor(c)
        (orbHalo.background as GradientDrawable).setColor(c)
        orbLabel.text = label
        pulse?.cancel(); orbBox.scaleX = 1f; orbBox.scaleY = 1f
        if (state != 0) {
            pulse = ValueAnimator.ofFloat(1f, if (state == 1) 1.22f else 1.1f).apply {
                duration = if (state == 2) 550 else 800
                repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
                addUpdateListener { orbBox.scaleX = it.animatedValue as Float; orbBox.scaleY = it.animatedValue as Float }
                start()
            }
        }
    }

    private fun refreshModes() {
        modeChips.forEachIndexed { i, c ->
            (c.background as GradientDrawable).setColor(Color.parseColor(if (i == mode) "#7C5CFF" else "#26265A"))
        }
    }

    private fun updateAction() {
        if (!::actionBtn.isInitialized || !::input.isInitialized) return
        val hasText = input.text.isNotBlank()
        actionBtn.text = if (hasText) "➤" else if (voiceMode) "⏹" else "🎤"
        (actionBtn.background as GradientDrawable).setColor(Color.parseColor(if (voiceMode) "#E5484D" else "#7C5CFF"))
    }

    private fun setBusy(b: Boolean) {
        busy = b
        stopBar.visibility = if (b) View.VISIBLE else View.GONE
        if (!b && !voiceMode && !voice.speaking) setOrb(0, "Taiyaar hoon")
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    private fun refreshStatus() {
        val acc = AgentService.instance != null
        val m = llm.hasModel()
        accRow.text = (if (acc) "✅" else "❌") + "  Phone control: Accessibility me Aiva ON karo" + if (acc) "" else "  (tap)"
        modelRow.text = (if (m) "✅" else "❌") + "  AI model file chunein" + if (m) "  (badalne ke liye tap)" else "  (tap)"
        setupCard.visibility = if (acc && m) View.GONE else View.VISIBLE
    }

    // ---------------- Bubbles ----------------
    private fun scrollDown() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun userBubble(t: String) {
        val tv = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(Color.WHITE); setTextIsSelectable(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#7C5CFF"), Color.parseColor("#5B8CFF"))).apply { cornerRadius = dp(18).toFloat() }
            maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
        }
        chat.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.END; topMargin = dp(8) })
        scrollDown()
    }

    private fun aivaBubble(t: String): TextView {
        val tv = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(Color.parseColor("#F1F0FF")); setTextIsSelectable(true)
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = bg("#24244D", 18)
            maxWidth = (resources.displayMetrics.widthPixels * 0.82).toInt()
        }
        chat.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.START; topMargin = dp(8) })
        scrollDown()
        return tv
    }

    private fun note(t: String) {
        val tv = TextView(this).apply {
            text = t; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#8E8CB0"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        chat.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        scrollDown()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- Toggles ----------------
    private fun toggleSpeak() {
        speakOn = !speakOn
        speakBtn.text = if (speakOn) "🔊" else "🔇"
        if (!speakOn) voice.stopSpeaking()
        toast(if (speakOn) "Aiva ab bolega" else "Aiva chup rahega (sirf likhega)")
    }

    private fun toggleLang() {
        voice.lang = if (voice.lang == "hi-IN") "en-IN" else "hi-IN"
        langBtn.text = if (voice.lang == "hi-IN") "हिं" else "EN"
        toast(if (voice.lang == "hi-IN") "Sunne ki bhasha: Hindi" else "Listening language: English")
    }

    private fun toggleVoice() {
        if (voiceMode) {
            voiceMode = false; voice.continuous = false
            voice.stopListening(); voice.stopSpeaking()
            setOrb(0, "Taiyaar hoon"); note("Voice mode band")
        } else {
            if (!llm.hasModel()) { note("Pehle AI model file chunein (⚙ dabayein)."); return }
            voiceMode = true; voice.continuous = true
            note("🎙 Voice mode ON — bolein, main sun raha hoon. Rokne ke liye ⏹ dabayein ya “ruko” bolein.")
            voice.startListening()
        }
        updateAction()
    }

    private fun stopAll() {
        cancelled = true; agent.stop = true
        llm.stopNow(); voice.stopSpeaking(); job?.cancel()
        note("Roka gaya.")
        if (voiceMode) voice.startListening()
    }

    // ---------------- Messaging ----------------
    private fun onHeard(text: String) {
        val t = text.trim()
        if (stopWords.matches(t)) { if (voiceMode) toggleVoice(); return }
        if (busy) { voice.startListening(); return }
        send(t)
    }

    private fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (busy) { toast("Aiva abhi soch raha hai, ek second…"); return }
        cancelled = false
        voice.stopSpeaking()
        userBubble(t)
        turns.add(true to t)
        setBusy(true)
        job = scope.launch {
            try {
                val q = if (mode != 1) agent.quick(t) else null
                if (q != null) { aivaSay(q); return@launch }
                if (!llm.hasModel()) { aivaSay("Pehle AI model file chunein, ⚙ dabayein."); return@launch }
                val wantTask = mode == 2 || (mode == 0 && taskRe.containsMatchIn(t))
                if (wantTask) {
                    if (AgentService.instance == null) {
                        aivaSay("Phone control ke liye pehle Accessibility me Aiva ko ON karein."); return@launch
                    }
                    setOrb(2, "Kaam kar raha hoon…")
                    aivaSay(agent.run(t))
                } else {
                    converse()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                aivaSay("Kuch gadbad hui: ${e.message}")
            } finally {
                setBusy(false)
            }
        }
    }

    private fun aivaSay(text: String) {
        aivaBubble(text)
        turns.add(false to text)
        if (turns.size > 14) turns.removeAt(0)
        finishReply(text)
    }

    private fun finishReply(text: String) {
        if (voiceMode || speakOn) { setOrb(3, "Bol raha hoon…"); voice.speak(text) }
        else setOrb(0, "Taiyaar hoon")
    }

    private suspend fun converse() {
        setOrb(2, "Soch raha hoon…")
        val tv = aivaBubble("…")
        val prompt = Prompts.chat(turns, llm.chatBudget)
        val raw = withContext(Dispatchers.Default) {
            try {
                llm.ask(prompt, 420, null) { p ->
                    if (!cancelled) runOnUiThread { tv.text = Prompts.clean(p); scrollDown() }
                }
            } catch (e: Throwable) { "ERROR:" + (e.message ?: e.javaClass.simpleName) }
        }
        if (cancelled) { tv.text = "(roka gaya)"; return }
        if (raw.isBlank()) { tv.text = "Aiva abhi pichhla jawab khatam kar raha hai. Thodi der baad try karein."; return }
        if (raw.startsWith("ERROR:")) { tv.text = "Maaf karein, jawab nahi bana.\n" + raw.take(160); return }
        val out = Prompts.trimToSentence(Prompts.clean(raw)).ifBlank { "Mujhe samajh nahi aaya, dobara kahenge?" }
        tv.text = out
        turns.add(false to out)
        if (turns.size > 14) turns.removeAt(0)
        finishReply(out)
    }

    // ---------------- Model ----------------
    private fun warmUp() {
        if (!llm.hasModel()) return
        setOrb(2, "Model load ho raha hai…")
        Thread {
            try {
                llm.load()
                runOnUiThread { setOrb(0, "Taiyaar hoon") }
            } catch (e: Throwable) {
                runOnUiThread {
                    note("Model load nahi hua: ${e.message}\nShayad file galat hai ya phone ke liye bhaari hai.")
                    setOrb(0, "Model problem")
                }
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 7) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (voiceMode) voice.startListening()
            } else {
                voiceMode = false; voice.continuous = false; updateAction()
                note("Mic permission nahi mili, isliye voice mode band hai.")
            }
        }
    }

    @Deprecated("simple starter")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != 1 || res != RESULT_OK || data == null) return
        val uri = data.data ?: return
        note("Model copy ho raha hai, thoda wait karein…")
        scope.launch(Dispatchers.IO) {
            try {
                llm.reset()
                contentResolver.openInputStream(uri)!!.use { i ->
                    llm.modelFile.outputStream().use { o -> i.copyTo(o) } }
                prefs.edit().putBoolean("safe", false).commit()
                withContext(Dispatchers.Main) { note("Model copy ho gaya ✅"); refreshStatus(); warmUp() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { note("Model copy fail: ${e.message}") }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voice.shutdown(); scope.cancel()
    }
}
