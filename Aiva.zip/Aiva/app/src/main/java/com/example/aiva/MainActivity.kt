package com.example.aiva

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.coroutines.*

class MainActivity : Activity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var llm: LlmEngine
    private lateinit var agent: Agent
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var accRow: TextView
    private lateinit var modelRow: TextView
    private var job: Job? = null

    private val purple = Color.parseColor("#6C4DFF")
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: String, r: Int) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(Color.parseColor(color))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        llm = LlmEngine(this)
        agent = Agent(llm) { msg -> runOnUiThread { bubble(msg, false) } }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FAF9FF"))
            setPadding(dp(16), dp(40), dp(16), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "Aiva"; textSize = 30f; setTypeface(null, Typeface.BOLD); setTextColor(purple)
        })
        root.addView(TextView(this).apply {
            text = "Aapka offline phone assistant"; textSize = 14f; setTextColor(Color.GRAY)
        })

        // Setup card
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = round("#FFFFFF", 14)
            setPadding(dp(14), dp(10), dp(14), dp(10)); elevation = dp(2).toFloat()
        }
        accRow = TextView(this).apply {
            textSize = 15f; setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        modelRow = TextView(this).apply {
            textSize = 15f; setPadding(0, dp(8), 0, dp(8))
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1)
            }
        }
        card.addView(accRow); card.addView(modelRow)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // Chat area
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })

        // Input bar
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val mic = TextView(this).apply {
            text = "🎤"; textSize = 22f; gravity = Gravity.CENTER
            setOnClickListener {
                try {
                    startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    }, 2)
                } catch (e: Exception) { toast("Is phone me voice input nahi hai") }
            }
        }
        input = EditText(this).apply {
            hint = "Kya karna hai? (jaise: Settings kholo)"; textSize = 15f
            background = round("#FFFFFF", 22); setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        val send = TextView(this).apply {
            text = "▶"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = round("#6C4DFF", 22)
            setOnClickListener { startTask() }
        }
        bar.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4); marginEnd = dp(8) })
        bar.addView(send, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val stop = TextView(this).apply {
            text = "⏹  Roko (Stop)"; textSize = 15f; setTextColor(Color.parseColor("#D32F2F"))
            gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(4))
            setOnClickListener { agent.stop = true; job?.cancel() }
        }
        root.addView(stop, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        bubble("Namaste! Main Aiva hoon. Pehle upar ke 2 setup step poore karein, phir mujhe koi kaam batayein.", false)
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    private fun refreshStatus() {
        val acc = AgentService.instance != null
        accRow.text = (if (acc) "✅" else "❌") + "  Step 1: Accessibility me Aiva ON karo" + if (acc) "" else "  (tap karein)"
        val m = llm.hasModel()
        modelRow.text = (if (m) "✅" else "❌") + "  Step 2: AI model file chunein" + if (m) "" else "  (tap karein)"
    }

    private fun startTask() {
        val goal = input.text.toString().trim()
        if (goal.isEmpty()) return
        if (AgentService.instance == null || !llm.hasModel()) {
            toast("Pehle dono setup step poore karein"); refreshStatus(); return
        }
        input.setText("")
        bubble(goal, true)
        job?.cancel()
        job = scope.launch { agent.run(goal) }
    }

    private fun bubble(text: String, mine: Boolean) {
        val tv = TextView(this).apply {
            this.text = text; textSize = 15f
            setTextColor(if (mine) Color.WHITE else Color.parseColor("#222222"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = round(if (mine) "#6C4DFF" else "#EEEAFF", 16)
        }
        chat.addView(tv, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = if (mine) Gravity.END else Gravity.START; topMargin = dp(6)
        })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Deprecated("simple starter")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (res != RESULT_OK || data == null) return
        if (req == 2) {
            val spoken = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (spoken != null) input.setText(spoken)
            return
        }
        val uri = data.data ?: return
        bubble("Model copy ho raha hai, thoda wait karein...", false)
        scope.launch(Dispatchers.IO) {
            try {
                contentResolver.openInputStream(uri)!!.use { i ->
                    llm.modelFile.outputStream().use { o -> i.copyTo(o) } }
                withContext(Dispatchers.Main) { bubble("Model taiyaar hai ✅", false); refreshStatus() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { bubble("Model copy fail: ${e.message}", false) }
            }
        }
    }
}
