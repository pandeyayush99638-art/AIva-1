package com.example.aiva

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** On-device model (MediaPipe). Model file app ke andar model.task naam se rakhi jaati hai. */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    val modelFile: File get() = File(ctx.filesDir, "model.task")
    fun hasModel(): Boolean = modelFile.exists() && modelFile.length() > 1_000_000

    fun generate(prompt: String): String {
        if (llm == null) {
            val opts = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(1536)
                .build()
            llm = LlmInference.createFromOptions(ctx, opts)
        }
        return llm!!.generateResponse(prompt)
    }
}
