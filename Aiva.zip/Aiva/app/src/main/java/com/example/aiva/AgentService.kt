package com.example.aiva

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Aiva ki aankhein aur haath: screen padhta hai aur actions karta hai. */
class AgentService : AccessibilityService() {

    companion object { @Volatile var instance: AgentService? = null }

    private var nodes = listOf<AccessibilityNodeInfo>()
    private val risky = Regex("pay|buy|purchase|delete|remove|send|transfer|place order|confirm", RegexOption.IGNORE_CASE)

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun label(n: AccessibilityNodeInfo): String =
        (n.text ?: n.contentDescription ?: n.hintText ?: "").toString().take(40)

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(no screen)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 30) return
            val useful = label(n).isNotBlank() || n.isClickable || n.isEditable
            if (useful && n.isVisibleToUser) list.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        return list.mapIndexed { i, n ->
            val tags = mutableListOf<String>()
            if (n.isClickable) tags.add("tap")
            if (n.isEditable) tags.add("input")
            if (n.isScrollable) tags.add("scroll")
            "[$i] ${label(n)} {${tags.joinToString(",")}}"
        }.joinToString("\n").ifBlank { "(empty screen)" }
    }

    fun tap(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "No such element $id"
        val l = label(n)
        if (risky.containsMatchIn(l)) return "BLOCKED: '$l' ke liye aapki ijazat chahiye"
        var t: AccessibilityNodeInfo? = n
        while (t != null && !t.isClickable) t = t.parent
        val target = t ?: n
        return if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "Tapped '$l'" else "Tap failed"
    }

    fun type(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: return "No such element $id"
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed" else "Type failed"
    }

    fun scroll(): String {
        val n = nodes.firstOrNull { it.isScrollable } ?: return "Nothing to scroll"
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) "Scrolled" else "Scroll failed"
    }

    fun back(): String { performGlobalAction(GLOBAL_ACTION_BACK); return "Back" }
    fun home(): String { performGlobalAction(GLOBAL_ACTION_HOME); return "Home" }

    fun openApp(name: String): String {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(name, ignoreCase = true)
        } ?: return "'$name' naam ka app nahi mila"
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return "Cannot launch"
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return "Opened ${app.loadLabel(pm)}"
    }
}
