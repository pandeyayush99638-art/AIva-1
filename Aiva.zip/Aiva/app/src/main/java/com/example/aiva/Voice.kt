package com.example.aiva

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Aiva ki aawaz (TTS) aur kaan (SpeechRecognizer). continuous = voice conversation mode. */
class Voice(private val act: Activity) {
    var onHeard: (String) -> Unit = {}
    var onListening: (Boolean) -> Unit = {}
    var onNote: (String) -> Unit = {}
    var onSpeakEnd: () -> Unit = {}
    var lang = "hi-IN"
    @Volatile var continuous = false
    @Volatile var speaking = false

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null
    private var errors = 0

    fun init() {
        tts = TextToSpeech(act) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { ended() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { ended() } }
                })
            }
        }
    }

    private fun ended() {
        speaking = false
        onSpeakEnd()
        if (continuous) main.postDelayed({ if (continuous) startListening() }, 450)
    }

    fun speak(text: String) {
        val t = tts
        if (t == null || !ttsReady) { main.post { ended() }; return }
        stopListening()
        val dev = text.any { it in '\u0900'..'\u097F' }
        val r = t.setLanguage(if (dev) Locale("hi", "IN") else Locale("en", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
        speaking = true
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aiva")
    }

    fun stopSpeaking() { tts?.stop(); speaking = false }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rms: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, b: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onResults(b: Bundle?) {
            val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            onListening(false)
            if (text.isEmpty()) { retry(); return }
            errors = 0
            onHeard(text)
        }
        override fun onError(code: Int) {
            onListening(false)
            when (code) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retry()
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { continuous = false; onNote("Mic ki permission chahiye.") }
                else -> {
                    errors++
                    if (errors > 3) {
                        errors = 0; continuous = false
                        onNote("Voice sunne me dikkat (error $code). Google Speech Services / internet check karein.")
                    } else retry(1200)
                }
            }
        }
    }

    private fun retry(delay: Long = 500) {
        if (!continuous) return
        main.postDelayed({ if (continuous && !speaking) startListening() }, delay)
    }

    fun startListening() {
        if (speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(act)) {
            continuous = false
            onNote("Is phone me speech recognition nahi mila. Google app / Speech Services install karein.")
            return
        }
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        main.post {
            try {
                rec?.destroy()
                rec = SpeechRecognizer.createSpeechRecognizer(act).also { it.setRecognitionListener(listener) }
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                rec?.startListening(i)
                onListening(true)
            } catch (e: Exception) {
                onNote("Mic start nahi hua: ${e.message}")
            }
        }
    }

    fun stopListening() {
        main.post {
            try { rec?.cancel(); rec?.destroy() } catch (_: Exception) {}
            rec = null
        }
    }

    fun shutdown() {
        continuous = false
        try { rec?.destroy() } catch (_: Exception) {}
        tts?.stop(); tts?.shutdown()
    }
}
