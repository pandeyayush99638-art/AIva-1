package com.example.aiva

object Prompts {
    private const val PERSONA =
        "You are Aiva, a friendly, smart voice assistant living on the user's Android phone. " +
        "Reply in the same language and script the user uses (Hindi, Hinglish or English). " +
        "Keep every reply short: 1 to 3 natural spoken sentences. No markdown, no emojis, no lists."

    fun clean(s: String): String =
        s.replace("<end_of_turn>", "").replace("<start_of_turn>", "").replace("<eos>", "")
            .replace(Regex("[*#`]"), "").trim()

    /** Gemma chat format, purani baatein yaad rakhta hai par budget ke andar. */
    fun chat(turns: List<Pair<Boolean, String>>, budget: Int): String {
        var used = PERSONA.length
        val picked = ArrayList<Pair<Boolean, String>>()
        for (i in turns.indices.reversed()) {
            val t = turns[i].second.take(500)
            if (picked.isNotEmpty() && used + t.length > budget) break
            used += t.length + 30
            picked.add(0, turns[i].first to t)
        }
        while (picked.isNotEmpty() && !picked[0].first) picked.removeAt(0)
        val sb = StringBuilder()
        var first = true
        for ((user, text) in picked) {
            if (user) {
                sb.append("<start_of_turn>user\n")
                if (first) sb.append(PERSONA).append("\n\n")
                sb.append(text).append("<end_of_turn>\n")
                first = false
            } else {
                sb.append("<start_of_turn>model\n").append(text).append("<end_of_turn>\n")
            }
        }
        sb.append("<start_of_turn>model\n")
        return sb.toString()
    }

    /** Jawab lamba ho gaya to aakhri poore vakya par kaat do. */
    fun trimToSentence(s: String): String {
        val idx = maxOf(s.lastIndexOf('.'), s.lastIndexOf('।'), s.lastIndexOf('?'), s.lastIndexOf('!'))
        return if (idx > s.length / 3) s.substring(0, idx + 1) else s
    }
}
